// pages/component/address/address.js
Page({
    data: {
        address:{
            name:'',
            phone:'',
            detail:''
        }
    },

    onLoad: function (options) {
        var self = this;

        wx.request({
            url: 'http://127.0.0.1:8000/getInfo?u_id=00001',
            method:"GET",
            header:{
              'content-type':'application/json',
            },
            success:(res)=> {
                console.log("success get info",res)
                if(res.statusCode==200){
                    let name = res.data.user_info['u_name'];
                    let location = res.data.user_info['address'];
                    let phone = res.data.user_info['phone']
                    this.setData({
                        address:{name:name,phone:phone,detail:location},
                        hasAddress:true,
                    })
                  //   console.log("this address",this.data.address)
                }
            }
          })
    },

    formSubmit(e){
        const value = e.detail.value;
        if(value.name && value.phone && value.detail){
            // wx.setStorage({
            //     key: 'address',
            //     data: value,
            //     success(){
            //         wx.navigateBack();
            //     }
            // })
            wx.request({
              url: 'http://127.0.0.1:8000/changeAddress',
              method:"POST",
              header:{
                'content-type':'application/json',
              },
              data:{
                  "u_id":"00001",
                  "u_name":value.name,
                  "phone":value.phone,
                  "address":value.detail
              },
              success:(res)=>{
                console.log("success in changeAddress:",res)
                if(res.statusCode==200){
                    this.setData({
                        name:res.data.u_name,
                        phone:res.data.phone,
                        detail:res.data.address
                    })
                }
              }

            })

        }else{
            wx.showModal({
                title:'提示',
                content:'请填写完整资料',
                showCancel:false
            })
        }
    }
})