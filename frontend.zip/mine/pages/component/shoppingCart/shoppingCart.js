// pages/component/shoppingCart/shoppingCart.js
Page({
    data: {
        // carts:[],       //购物车列表
        hasList:false,  //列表是否有数据
        totalPrice:0,   //总价，初值为0
        selectAllStatus:true,       //全选状态，默认全选
        // obj:{
        //     name:"hello"
        // }

        products_shopping:[],
        Info:[]
    },
    onLoad:function() {
        console.log('test in onLoad')
    },

    onShow:function(){
        console.log('test in shoppingCart')
        
        wx.request({
          url: 'http://127.0.0.1:8000/shoppingCart?u_id=00001',
          method:"GET",
          header:{
            'content-type':'application/json',
          },
          success:(res)=> {
              console.log("success in shop:",res)
              if(res.statusCode==200){
                  this.setData({
                    products_shopping:res.data.shopping_cart_list
                  })
                  if(this.data.products_shopping != []){
                    this.setData({
                      hasList:true
                    })
                  }
                  let tmp = res.data.shopping_cart_list
                  for(let j = 0,len=this.data.products_shopping.length; j < len; j++) {
                    tmp[j]['selected'] = true
                    // console.log('selected true')
                  }
                  this.setData({
                    products_shopping:tmp,
                    Info:tmp
                  })

                  if(this.products_shopping != []) {
                    this.data.hasList = true
                  }
                 
                  console.log('this.totalPrice:', this.data.totalPrice)
                  console.log('this.shopping:',this.data.products_shopping)

                  this.getTotalPrice();
              }
          }
        })
    },

    /* 当前商品选中 */
    selectList(e){
        
        const index = e.currentTarget.dataset.index;
        console.log('index:', index)
        let products_shopping = this.data.products_shopping;
        console.log('product_shopping in selectList:', products_shopping)
        const selected = products_shopping[index]['selected'];
        products_shopping[index]['selected'] = !selected;

        this.setData({
          products_shopping: products_shopping
        });
        // if(this.data.products_shopping[index]['selected']==false){
        //   this.setData({
        //     selectAllStatus:false
        //   });
        // }
        let count = 0;
        let tmp = [];
        for(let j=0;j<this.data.products_shopping.length;j++){
          if(this.data.products_shopping[j]['selected']==false){
            count++;
          }
          else{
            tmp.push(products_shopping[j]);
            console.log("tmp in cart:",tmp);
          }
          
        }
        console.log("tmp outside:",tmp);
        this.setData({
          Info:tmp
        })
        console.log("Info is tmp:",this.data.Info);
          if(count == 0) {
            this.setData({
              selectAllStatus:true
            });
          }
          else{
            this.setData({
              selectAllStatus:false
            });
        }

        this.getTotalPrice();
        

    },

    /* 删除购物车当前商品 */
    deleteList(e) {
        let index = e.currentTarget.dataset.index;
        console.log('index:', index)
        let products_shopping = this.data.products_shopping;
        console.log('products_shopping:', products_shopping)
        
        let pid=this.data.products_shopping[index]['p_id'];
        console.log('index:', index)
        console.log('test 1:', this.data.products_shopping[index]['p_id'])
        // console.log('pid in shoppingCart:', pid)
        
        wx.request({
          url: 'http://127.0.0.1:8000/delProduct',
          method:"DELETE",
          header:{
            'content-type':'application/json',
          },
          data:{
            "u_id":"00001",
            "p_id":pid
          },
          success:(res)=>{
            console.log('success when deleting:',res)
            if(res.statusCode==200){
            //   this.setData({
            //     products_shopping=this.data.products_shopping,
            //   })
            //   console.log('this.pro_shopping:',this.data.products_shopping)
            products_shopping.splice(index,1);
            this.setData({
              products_shopping: products_shopping
            });
            console.log('test in shoppingCart:', this.data.products_shopping.length)
            if(!this.data.products_shopping.length){
                this.setData({
                    hasList: false
                });
            }else{
                this.getTotalPrice();
            }
            }
          }
        })
    },

    // /* 购物车全选 */
    selectAll(e) {
        let selectAllStatus = this.data.selectAllStatus;
        selectAllStatus = !selectAllStatus;
        let products_shopping = this.data.products_shopping;

        for(let i = 0;i<products_shopping.length;i++){
          products_shopping[i]['selected'] = selectAllStatus;
        }
        this.setData({
            selectAllStatus:selectAllStatus,
            products_shopping:products_shopping
        });
        this.getTotalPrice()
    },

    // /* 绑定加数量事件 */
    addCount(e) {
        const index = e.currentTarget.dataset.index;
        let products_shopping = this.data.products_shopping;
        let num = products_shopping[index]['number'];
        num = num + 1;
        products_shopping[index]['number'] = num;
        this.setData({
          products_shopping:products_shopping
        });
        this.getTotalPrice();
    },

    // /* 绑定减数量事件 */
    minusCount(e) {
        const index = e.currentTarget.dataset.index;
        const obj = e.currentTarget.dataset.obj;
        let products_shopping = this.data.products_shopping;
        let num = products_shopping[index]['number'];
        if(num <= 1){
            return false;
        }
        num = num - 1;
        products_shopping[index]['number'] = num;
        this.setData({
          products_shopping:products_shopping
        });
        this.getTotalPrice();
    },

    // /* 计算总价 */
    getTotalPrice() {
        let products_shopping = this.data.products_shopping;        //获取购物车列表
        console.log('this.product_list:', this.data.products_shopping)
        let total = 0;
        for(let i=0;i<products_shopping.length;i++){
            if(products_shopping[i]['selected']) {
                total += products_shopping[i]['number'] * products_shopping[i]['price'];
                console.log('total:',total);
            }
        }
        this.setData({
          // products_shopping:products_shopping,
          totalPrice:total,
        });
        console.log('total before return:', total)
        console.log('totalPrice:', this.data.totalPrice)
        return total
    },

    tobackend() {
      
      console.log("this info",this.data.Info);
      wx.request({
        url: 'http://127.0.0.1:8000/getOrderList',
        method:"POST",
        header:{
          'content-type':'application/json',
        },
        data:{
          "u_id":"00001",
          "product_list": this.data.Info,
          "from_cart":1
        },
      })
    }



})

