// pages/component/shoppingCart/shoppingCart.js
Page({
    data: {
        // carts:[],       //购物车列表
        hasList:false,  //列表是否有数据
        // totalPrice:0,   //总价，初值为0
        // selectAllStatus:true,       //全选状态，默认全选
        // obj:{
        //     name:"hello"
        // }
        products_collection:[]
    },

    onLoad:function() {
        console.log('test in onLoad')
    },

    onShow:function(){
        console.log('test in collection')
        
        wx.request({
          url: 'http://127.0.0.1:8000/collect?u_id=00001',
          method:"GET",
          header:{
            'content-type':'application/json',
          },
          success:(res)=> {
              console.log("success in shop:",res)
              if(res.statusCode==200){
                  this.setData({
                    products_collection:res.data.collect_list
                  })
                  if(this.data.products_collection != []){
                    this.setData({
                      hasList:true
                    })
                  }
                  
              }
          }
        })
    },

    
})