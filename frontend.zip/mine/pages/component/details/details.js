// pages/component/details/details.js.js
Page({

    data: {
        // goods:{
        //     id: 1,
        //     image: '/image/p1.png',
        //     title: '商品名',
        //     price: 0.01,
        //     stock: '有货',
        //     detail: '这里是详情',
        //     parameter: '125g/个',
        //     service: '不支持退货'
        // },
        // num: 1,
        // totalNum: 0,
        hasCarts: false,
        hasCollect: false,
        // curIndex: 0,
        // show: false,
        scaleCart: false,
        product_info:{},
        num:0,
        totalNum:0,
        p_id:'',
        inCollect:''
    },

    // onLoad:function(options) {
    //     console.log('options:', options)
    //     console.log('detail onLoad')
    // },

    onLoad:function(options) {
        console.log('detail onShow')
        console.log('options:', options)
        console.log('p_id:', options.p_id)
        wx.request({
          url: 'http://127.0.0.1:8000/getDetail?u_id=00001&p_id='+options.p_id,
          // url:'http://127.0.0.1:8000/getDetail?p_id=00001',
          method:"GET",
          header:{
            'content-type':'application/json',
          },
          success:(res)=>{
              console.log('success:', res)
              if(res.statusCode==200) {
                  this.setData({
                      product_info:res.data.detail,
                      p_id:options.p_id,
                      inCollect:res.data.detail['is_collected']
                    // p_id:'00001'
                  })
                  console.log('this.pro:', this.data.product_info)
              }
          }
        })
    },

    addCount() {
        let num = this.data.num;
        num++;
        this.setData({
            num : num
        })
    },

    minusCount() {
        let num = this.data.num;
        if(num <= 1){
            return false;
        }
        num--;
        this.setData({
            num : num
        })
    },

    addShoppingCart() {
        const self = this;
        const num = this.data.num;
        let total = this.data.totalNum;

        self.setData({
            show: true,
            totalNum:num,
            hasCarts:false
        }),
        wx.request({
          url: 'http://127.0.0.1:8000/addShoppingCart',
          method:"POST",
          header:{
            'content-type':'application/json',
          },
          data:{
            "u_id":"00001",
            "p_id": this.data.p_id,
            'number':this.data.totalNum
          },
          success:(res)=>{
            console.log('res:', res)
            if(res.statusCode == 200) {
                console.log('success')
            }
          }

        })
    },

    addCollect(){
      const self = this;

      self.setData({
        show:true,
        hasCollect:false
      }),
      wx.request({
        url: 'http://127.0.0.1:8000/addCollect',
        method:"POST",
        header:{
          'content-type':'application/json',
        },
        data:{
          "u_id":"00001",
          "p_id":this.data.p_id
        },
        success:(res)=>{
          console.log("addCol success",res)
          if(res.statusCode==200){
            console.log("yea")
            this.setData({
              inCollect: true
            })
          }
        }
      })
    },

    subCollect(){
      const self = this;
      self.setData({
        show:true,
        hasCollect:true
      }),
      wx.request({
        url: 'http://127.0.0.1:8000/subCollect',
        method:"DELETE",
        header:{
          'content-type':'application/json',
        },
        data:{
          "u_id":"00001",
          "p_id":this.data.p_id
        },
        success:(res)=>{
          console.log("subCol success",res)
          if(res.statusCode==200){
            console.log("yea")
            this.setData({
              inCollect: false
            })
          }
        }
      })
    },

    bindTap(e) {
        const index = parseInt(e.currentTarget.dataset.index);
        this.setData({
          curIndex: index
        }) 
    }
})