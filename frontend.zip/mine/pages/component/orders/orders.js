// pages/component/orders/orders.js
Page({
    data: {
        address:null,
        name:null,
        phone:null,
        hasAddress: false,
        total:0,
        // orders:[
        //     {id:1,title:'香菜 半斤',image:'/image/p6.png',num:4,price:0.01},
        //     {id:2,title:'米 半斤',image:'/image/p7.png',num:1,price:0.03}
        // ]
        product_orders:[],
        Info: [],
        from_cart:null
    },

    // onReady() {
    //     this.getTotalPrice();
    // },
    // onLoad:function(options) {
    //     this.setData({
    //         from_cart:options.from_cart
    //     });
    //     this.getTotalPrice();
    // },

    onShow: function () {
        const self = this;
        wx.request({
          url: 'http://127.0.0.1:8000/getInfo?u_id=00001',
          method:"GET",
          header:{
            'content-type':'application/json',
          },
          success:(res)=> {
              console.log("success get info",res)
              if(res.statusCode==200){
                  this.setData({
                      name:res.data.user_info['u_name'],
                      address:res.data.user_info['address'],
                      phone:res.data.user_info['phone'],
                      hasAddress:true
                  })
                //   console.log("this address",this.data.address)
              }
          }
        })
        // console.log("getStorage res:");

        // setTimeout(function () {
        //     //要延时执行的代码
        //     wx.getStorage({
        //         key:'key',
        //         fail:function(res) {
        //             console.log('fali')
        //             console.log('res:', res)
        //         //    return false;
        //         },
        //         success: function(res) {
        //             console.log("getStorage res:",res.data);
        //             this.Info = res.data
        //         }
        //     })
        //    }, 2000) //延迟时间 这里是1秒
        

        wx.request({
          url: 'http://127.0.0.1:8000/getOrderList',
          method:"POST",
          header:{
            'content-type':'application/json',
          },
          data:{
              "u_id":"00001",
              "product_list":[],
              "from_cart":0
          },
          success:(res)=>{
              console.log('success in orders:',res)
              if(res.statusCode==200){
                  this.setData({
                    product_orders:res.data.order_list
                  });
                  this.getTotalPrice();
              }
          }
        })
        //this.getTotalPrice();
    },

    /* 计算总价 */
    getTotalPrice() {
        let product_orders = this.data.product_orders;
        console.log("product_orders:",product_orders)
        let totall = 0;
        for(let i = 0; i < product_orders.length; i++){
            totall += product_orders[i].price;
            // console.log("product_orders[i][price]:",product_orders[i]['price'])
        }
        console.log("totallllll:",totall)
        this.setData({
            total:totall
        })
    },

    toPay() {
        // let tmp = '付款失败';
        // wx.request({
        //     url: 'http://127.0.0.1:8000/pay',
        //     method:"POST",
        //     header:{
        //       'content-type':'application/json',
        //     },
        //     data:{
        //         "u_id":"00001",
        //         "product_list":this.data.product_orders,
        //     },
        //     success:(res)=>{
        //         //console.log('success in pay:',res)
        //         if(res.statusCode==200){
        //             tmp:'付款成功！'
        //         }
                
        //     }
        //   })
        
        wx.showModal({
            title: '提示',
            content: '付款成功',
            text:'center',
            complete(){
                wx.switchTab({
                  url: '../user/user'
                })
            }
        })

    }
})