// pages/component/user/user.js
Page({
    data: {
        // thumb:'',
        nickname:'',
        // orders:[],
        hasAddress:false,
        // address:{}
        address:{},
        picture:'',
        money:''
    },
    // onLoad(){
    //     var self = this;

    //     /* 获取用户信息 */
    //     wx.getUserInfo({
    //       success: function(res){
    //           self.setData({
    //               thumb: res.userInfo.avatarUrl,
    //               nickname: res.userInfo.nickName
    //           })
    //       }
    //     }),

    //     /* 发起请求获取订单列表信息 */
    //     wx.request({
    //         url: 'http://127.0.0.1:8000/home',
    //         success(res){
    //           self.setData({
    //             orders: res.data
    //           })
    //         }
    //       })
    // },
    onload: function() {
      // console.log("test")
      // return request({
      //   url: "http://127.0.0.1:8000/home",
      //   method:"GET"
      // }).then(()=>{
      //   console.log("test 2")
      // })
    },
    onShow(){
        var self = this;

        wx.request({
          url: 'http://127.0.0.1:8000/getInfo?u_id=00001',
          method:"GET",
          header:{
            'content-type':'application/json',
          },
          success:(res)=> {
              console.log("success get info",res)
              if(res.statusCode==200){
                  let name = res.data.user_info['u_name'];
                  let location = res.data.user_info['address'];
                  let phone = res.data.user_info['phone'];
                  this.setData({
                      address:{name:name,phone:phone,detail:location},
                      hasAddress:true,
                      nickname:res.data.user_info['u_name'],
                      picture:res.data.user_info['portrait_path'],
                      money:res.data.user_info['money'],
                  })
                //   console.log("this address",this.data.address)
              }
          }
        })

        
    },

})