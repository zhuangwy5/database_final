// pages/component/division/division.js
Page({
    data: {
        category:[
            {name:'服饰',id:'fushi'},
            {name:'电子产品',id:'dianzi'},
            {name:'零食',id:'lingshi'},
        ],
        detail:[],
        curIndex:0,
        isScroll: false,
        toView:'fushi',
        cata_pro1:[],
        cata_pro2:[],
        cata_pro3:[]
    },

    onShow(){
        this.getCata1();
        this.getCata2();
        this.getCata3();
    },

    switchTab(e){
        const self = this;
        this.setData({
            isScroll: true
        })
        setTimeout(function(){
            self.setData({
                toView: e.target.dataset.id,
                curIndex: e.target.dataset.index
            })
        },0)
        setTimeout(function () {
            self.setData({
                isScroll: false
            })
        }, 1);
    },

    getCata1() {
        const self = this;
        wx.request({
          url: 'http://127.0.0.1:8000/division?tag=1',
          method:"GET",
          header:{
            'content-type':'application/json',
          },
          success:(res)=>{
              console.log('success in getCata1:',res)
              if(res.statusCode==200){
                  this.setData({
                      cata_pro1:res.data.tag_product_list
                  });
              }
          }
        })
    },

    getCata2() {
        const self = this;
        wx.request({
          url: 'http://127.0.0.1:8000/division?tag=2',
          method:"GET",
          header:{
            'content-type':'application/json',
          },
          success:(res)=>{
              console.log('success in getCata2:',res)
              if(res.statusCode==200){
                  this.setData({
                      cata_pro2:res.data.tag_product_list
                  });
              }
          }
        })
    },

    getCata3() {
        const self = this;
        wx.request({
          url: 'http://127.0.0.1:8000/division?tag=3',
          method:"GET",
          header:{
            'content-type':'application/json',
          },
          success:(res)=>{
              console.log('success in getCata3:',res)
              if(res.statusCode==200){
                  this.setData({
                      cata_pro3:res.data.tag_product_list
                  });
              }
          }
        })
    }
})