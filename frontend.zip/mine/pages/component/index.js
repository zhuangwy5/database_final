// pages/component/index.js
Page({
    /* 页面的初始数据 */
    data: {
        // imgUrls: [
        //     '/image/b1.jpg',
        //     '/image/b2.jpg',
        //     '/image/b3.jpg'
        // ],
        // indicatorDots: false,
        // autoplay: false,
        // interval: 3000,
        // duration: 800,
        product_list:[]
    },
    onLoad:function() {
        console.log('test 1')
        wx.request({
          url: 'http://127.0.0.1:8000/',
          method:"GET",
          header:{
              'content-type':'application/json',
          },
          success:(res)=>{
              console.log('success:', res)
              console.log('data:', res.data.product_list)
              console.log('code:', res.statusCode)
              if(res.statusCode == 200) {
                  this.setData({
                      product_list:res.data.product_list
                  })
                  console.log('this.pro:', this.data.product_list)
              }
          }
        }
        )
    }
})


