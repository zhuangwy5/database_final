// app.js
App({
  onLaunch: function(){
    console.log('App Launch')
    var url="http:127.0.0.1:8000/"
    wx.getSystemInfo({
      success: e => {
        console.log('test here')
      },
    })
  },
  onShow: function(){
    console.log('App Show')
  },
  onHide: function(){
    console.log('App Hide')
  },
  globalData: {
    hasLogin: false,
    server:'http://127.0.0.1:8000'
  }
})
